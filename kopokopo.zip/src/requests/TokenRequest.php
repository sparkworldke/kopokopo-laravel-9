<?php

namespace Kopokopo\SDK\Requests;

class TokenRequest extends BaseRequest
{
}
